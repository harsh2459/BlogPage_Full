import './output.css'
import { Route, Routes } from 'react-router-dom';
import './App.css';
import Header from './components/Header';
import Footer from './components/Footer';
import Home from './pages/Home';
import Single_Blog from './components/Single_Blog';
import CreateBlog from './pages/CreateBlog';
import DeleteBlog from './pages/DeleteBlog';
import UpdateBlog from './pages/UpdateBlog';
import { useEffect, useState } from 'react';
import axios from 'axios';
import AddCategory from './pages/AddCategory';

function App() {
  const [category, setcategory] = useState([])

  useEffect(() => {
    axios.get(`http://localhost:3000/show_category`)
      .then(function (response) {
        setcategory(response.data.data);
      })
      .catch(function (error) {
        console.log(error);
      })
  },[])

  return (
    <div>
      <Header />
      <Routes>
        <Route path="/" element={<Home  newcategory={category}/>} />
        <Route path="/createblog" element={<CreateBlog newcategory={category}/>} />
        <Route path="SingleBlog/:id" element={<Single_Blog />} />
        <Route path="/DeleteBlog" element={<DeleteBlog />} />
        <Route path="/UpdateBlog/:id" element={<UpdateBlog  newcategory={category}/>} />
        <Route path="/addcategory" element={<AddCategory newcategory={category}/>} />
      </Routes>
      <Footer />
    </div>
  );
}

export default App;
