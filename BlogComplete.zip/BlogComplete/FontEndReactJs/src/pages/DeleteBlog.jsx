import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';

const DeleteBlog = () => {

  const [blog, setblog] = useState([])

  useEffect(() => {

    axios.get('http://localhost:3000/blog_post')
      .then(function (response) {
        setblog(response.data.data);
      })
      .catch(function (error) {
        console.log(error);
      })
  }, []);

  const DeleteBlog = (id) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this blog post?");
    if (confirmDelete) {
      axios.get(`http://localhost:3000/delete_blog/${id}`)
        .then(function (response) {
          console.log(response);
        })
        .catch(function (error) {
          console.log(error);
        })
    }
    else {
      console.log("You clicked cancel");
    }
  }

  return (
    <div>
      <div className='flex justify-center pt-11 flex-wrap	'>
        {
          blog.map((item, index) => {
            return (
              <Link className='p-4'>
                <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                  <Link className='images_card'>
                    <img class="rounded-t-lg" src={item.image} alt="" />
                  </Link>
                  <div class="p-5">
                    <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">{item.title}</h5>
                    <div className='flex'>
                      <p class="mb-3 pr-5 font-normal text-gray-700 dark:text-gray-400">{item.name}</p>
                      <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">{item.category}</p>
                    </div>
                    <Link to="/" onClick={() => DeleteBlog(item._id)} class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-red-700 rounded-lg hover:bg-red-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                      Delete Blog
                    </Link>
                  </div>
                </div>
              </Link>
            )
          })
        }
      </div>
    </div>
  )
}

export default DeleteBlog