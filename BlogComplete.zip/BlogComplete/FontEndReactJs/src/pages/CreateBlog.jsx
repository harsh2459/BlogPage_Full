import axios from 'axios'
import React, { useEffect, useState } from 'react'

const CreateBlog = (props) => {
    const [blog, setblog] = useState({
        title: "",
        content: "",
        name: "",
        image: "",
        category: ""
    })


    const handleInputChange = (event) => {
        setblog({ ...blog, [event.target.name]: event.target.value });
    };

    const CreateBlog = () => {
        axios.post('http://localhost:3000/blog_create', blog)
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });
    }


    return (
        <div>
            <form class="max-w-sm mt-8 mx-auto">
                <label for="website-admin" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Author Name</label>
                <div class="flex mb-5">
                    <input type="text" name='name' onChange={handleInputChange} id="text" aria-describedby="helper-text-explanation" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="AuthorName" />
                </div>
                <label for="website-admin" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Blog Title.</label>
                <div class="flex mb-5">
                    <input type="text" name='title' onChange={handleInputChange} id="text" aria-describedby="helper-text-explanation" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="BlogTitle" />
                </div>
                <label for="category" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select Blog category</label>
                <select id="category" name='category' onChange={handleInputChange} class="bg-gray-50 border mb-5 border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="">Select Category</option>
                    {
                        props.newcategory.map((cat, index) => {
                            return (
                                <option>{cat.category}</option>
                            )
                        })
                    }
                </select>
                <label for="website-admin" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Image Link</label>
                <div class="flex mb-5">
                    <input type="text" name='image' onChange={handleInputChange} id="text" aria-describedby="helper-text-explanation" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Enter Image Link" />
                </div>
                <label htmlFor="message" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Blog content</label>
                <div className="relative mb-5">
                    <textarea
                        id="message"
                        name='content'
                        onChange={handleInputChange}
                        rows="4"
                        maxLength="50000" // Set a maximum length
                        className="block p-2.5 w-full h-svh text-sm text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500 resize-none" // Added resize-none to prevent resizing
                        placeholder="Write your blog content here (max 50000 characters)..."
                    ></textarea>
                    <span className="absolute right-2 bottom-2 text-sm text-gray-500">{blog.content.length}/50000</span>
                </div>
                <button type="submit" onClick={CreateBlog} class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>
            </form>
        </div>
    )
}

export default CreateBlog