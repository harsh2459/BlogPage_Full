import axios from 'axios';
import React, { useState } from 'react'

const AddCategory = (props) => {

    const [category, setcategory] = useState({
        category: '',
        id: null,
    })

    const handleInputChange = (event) => {
        setcategory({ ...category, [event.target.name]: event.target.value });
    };

    console.log(category.category);

    const { id } = category;
    console.log(id);


    const CreateCategory = () => {
        if (category.id) {
            axios.post(`http://localhost:3000/update_category/${id}`, category)
                .then(function (response) {
                    console.log(response);
                    setcategory({ category: '', id: null });
                    window.location.reload();
                })
                .catch(function (error) {
                    console.log(error);
                });
        } else {
            axios.post('http://localhost:3000/add_category', { category: category.category })
                .then(function (response) {
                    console.log(response);
                    setcategory({ category: '', id: null });
                    window.location.reload();
                })
                .catch(function (error) {
                    console.log(error);
                });
        }
    }

    const UpdateCategory = (category, id) => {
        setcategory({ category: category, id: id });
    }

    const DeleteCategory = (id) => {
        const confirmDelete = window.confirm("Are you sure you want to delete Category?");
        if (confirmDelete) {
            axios.get(`http://localhost:3000/delete_category/${id}`)
                .then(function (response) {
                    window.location.reload();
                })
                .catch(function (error) {
                    console.log(error);
                });
        } else {
            console.log("Delete Cancelled");
        }
    }

    return (
        <div>

            <form class="max-w-sm mx-auto mt-12" onSubmit={(e) => { e.preventDefault(); CreateCategory(); }}>
                <label for="text" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Enter Category</label>
                <input type="text" value={category.category} id="category" name='category' onChange={handleInputChange} aria-describedby="helper-text-explanation" class="mb-5 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5  dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="Enter Category" />
                <button type="submit" class="mb-5 text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Submit</button>

            </form>



            <div class="relative overflow-x-auto mt-12">
                <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
                    <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">
                                Category
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Update
                            </th>
                            <th scope="col" class="px-6 py-3">
                                Delete
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        {
                            props.newcategory.map((item, index) => {
                                return (
                                    <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                                        <th scope="row" class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">
                                            {item.category}
                                        </th>
                                        <td class="px-6 py-4">
                                            <button onClick={() => UpdateCategory(item.category, item._id)} className="text-white bg-gray  dark:text-white  focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 dark:hover:bg-gray-700 focus:outline-none dark:focus:ring-gray-800">UpdateCategory</button>
                                        </td>
                                        <td class="px-6 py-4">
                                            <button onClick={() => DeleteCategory(item._id)} className="text-white bg-red-700 hover:bg-red-800 dark:text-white  focus:ring-4 focus:ring-gray-300 font-medium rounded-lg text-sm px-4 lg:px-5 py-2 lg:py-2.5 mr-2 dark:hover:bg-gray-700 focus:outline-none dark:focus:ring-gray-800">DeleteCategory</button>
                                        </td>
                                    </tr>
                                )
                            })
                        }

                    </tbody>
                </table>
            </div>



        </div>
    )
}

export default AddCategory