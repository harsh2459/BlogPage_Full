import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'

const Home = (props) => {

    const [blog, setblog] = useState([])
    const [selectedCategory, setSelectedCategory] = useState('All');
    const [totalPosts, setTotalPosts] = useState(0);
    const [currentPage, setCurrentPage] = useState(1);
    const [limit, setlimit] = useState(1);

    const handlePageChange = (page) => {
        axios.get(`http://localhost:3000/blog_post/?page=${page}&limit=${limit}`)
            .then(function (response) {
                setblog(response.data.data);
                setTotalPosts(response.data.total);
            })
            .catch(function (error) {
                console.log(error);
            })
    }

    useEffect(() => {
        handlePageChange(currentPage);
    }, [currentPage,limit]);

    const handleCategoryChange = (event) => {
        setSelectedCategory(event.target.value);
    };

    console.log(limit);

    const totalPages = Math.ceil(totalPosts / limit);

    return (
        <div>
            <div className="flex mt-12 w-36 ml-10">
                <select id="category" name='category' onChange={handleCategoryChange} class="category-limit bg-gray-50 border mb-5 border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="All">All Category</option>
                    {
                        props.newcategory.map((cat, index) => {
                            return (
                                <option>{cat.category}</option>
                            )
                        })
                    }
                </select>
                <select onChange={(e) => setlimit(Number(e.target.value))}  className="BlogPostLimit bg-gray-50 border mb-5 border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="5">5</option>
                    <option value="10">10</option>
                </select>
            </div>

            <div className='flex justify-center pt-11 flex-wrap	'>
                {
                    blog.filter(item => selectedCategory === 'All' || item.category === selectedCategory)
                        .map((item, index) => {
                            return (
                                <div className='p-4'>
                                    <div class="max-w-sm bg-white border border-gray-200 rounded-lg shadow dark:bg-gray-800 dark:border-gray-700">
                                        <div className='images_card'>
                                            <img class="rounded-t-lg" src={item.image} alt="" />
                                        </div>
                                        <div class="p-5 blog-contect">
                                            <h5 class="mb-2 text-2xl font-bold tracking-tight text-gray-900 dark:text-white">{item.title}</h5>

                                            <div className='flex'>
                                                <p class="mb-3 pr-5 font-normal text-gray-700 dark:text-gray-400">{item.name}</p>
                                                <p class="mb-3 font-normal text-gray-700 dark:text-gray-400">{item.category}</p>

                                            </div>
                                            <Link to={`SingleBlog/${item._id}`} class="inline-flex items-center px-3 py-2 text-sm font-medium text-center text-white bg-blue-700 rounded-lg hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                Read more
                                                <svg class="rtl:rotate-180 w-3.5 h-3.5 ms-2" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 10">
                                                    <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M1 5h12m0 0L9 1m4 4L9 9" />
                                                </svg>
                                            </Link>
                                            <Link to={`/UpdateBlog/${item._id}`} class="inline-flex items-center px-3 ml-24 py-2 text-sm font-medium text-center text-grey  rounded-lg hover:text-blue focus:ring-4 focus:outline-none focus:ring-blue-300 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">
                                                Update Blog
                                            </Link>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                }
            </div>
            <div>
                <div class="flex justify-center mt-24">
                    <button onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} disabled={currentPage === 1} class="flex items-center justify-center px-3 h-8 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                        Previous
                    </button>

                    <button onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))} disabled={currentPage === totalPages} class="flex items-center justify-center px-3 h-8 ms-3 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                        Next
                    </button>
                </div>
            </div>
        </div>
    )
}

export default Home