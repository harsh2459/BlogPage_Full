import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'

const Single_Blog = () => {

    const { id } = useParams()
    const [blog, setBlog] = useState([])
    const { title, content, name, date, image, category } = blog;

    const formattedDate = new Date(date);
    const day = formattedDate.getDate();
    const year = formattedDate.getFullYear();


    useEffect(() => {
        axios.get(`http://localhost:3000/single_blog/${id}`)
            .then(function (response) {
                setBlog(response.data.data);
            })
            .catch(function (error) {
                console.log(error);
            })
    }, [])

    return (
        <div>

            <section>
                <div className="container">
                    <div className="row">
                        <div className="col-md-12">
                            <h1 className="text-center pt-8 font-medium text-4xl font-serif">{title}</h1><br />
                        </div>
                    </div>
                    <div className="row flex pt-4 font-serif">
                        <div className="col-md-6 ml-32">
                            <h3>By {name ? name : 'Unknown'}  | Published On {day},{year} | Category: {category}</h3>
                        </div>
                    </div>
                    <div className="row flex justify-center">
                        <div className=" Blog-Image">
                            <img src={image} alt="blog image" className="img-fluid mt-20" />
                        </div>
                    </div>
                    <div className="row ml-32">
                        <p className='font-serif mt-20'>{content}</p>
                    </div>
                </div>
            </section>

        </div>
    )
}

export default Single_Blog


