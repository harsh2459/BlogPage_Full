import axios from 'axios';
import React, { useState } from 'react'

const Pagination = () => {

    const [currentPage, setCurrentPage] = useState(1);

    const handlePageChange = () => {
        axios.get(`http://localhost:3000/blog_post/?page=${currentPage}`)
            .then(function (response) {
                console.log(response);

            })
            .catch(function (error) {
                console.log(error);
            })
    }
    handlePageChange();

    return (
        <div>
            <div class="flex justify-center mt-24">
                <button disabled={currentPage === 1} class="flex items-center justify-center px-3 h-8 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                    Previous
                </button>

                <button class="flex items-center justify-center px-3 h-8 ms-3 text-sm font-medium text-gray-500 bg-white border border-gray-300 rounded-lg hover:bg-gray-100 hover:text-gray-700 dark:bg-gray-800 dark:border-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white">
                    Next
                </button>
            </div>
        </div>
    )
}

export default Pagination;