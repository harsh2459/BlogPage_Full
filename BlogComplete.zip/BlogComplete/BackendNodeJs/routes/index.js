var express = require('express');
var router = express.Router();
var user = require('../controller/user_side')
var blog = require('../controller/blog');
var category = require('../controller/category')
/* GET home page. */
      
router.post('/user_signup', user.user_signup)
router.post('/user_delete', user.delete_user)
router.post('/user_login', user.user_login)

// blog api
router.post('/blog_create', blog.add_blog);
router.get('/blog_post', blog.get_blog_posts);
router.get('/single_blog/:id', blog.single_blog);
router.post('/update_blog/:id', blog.update_blog);
router.get('/delete_blog/:id', blog.delete_blog);

// category
router.get('/delete_category/:id', category.delete_category)
router.get('/short_category/:category', category.short_by_category)
router.get('/show_category', category.show_category)
router.post('/add_category', category.add_category)
router.post('/update_category/:id', category.update_category)


module.exports = router;
