var mongoose = require('mongoose');

var blog = new mongoose.Schema({

    title: {
        type: String
    },
    content: {
        type: String
    },
    name: {
        type: String
    },
    date: {
        type: String
    },
    image: {
        type: String
    },
    category: {
        type: String
    },

})

module.exports = mongoose.model('blog', blog);            