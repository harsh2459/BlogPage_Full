var mongoose = require('mongoose');

var category = new mongoose.Schema({

    category:{
        type:String
    },

})

module.exports = mongoose.model('category', category);            