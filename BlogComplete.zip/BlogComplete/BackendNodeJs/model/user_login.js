var mongoose = require('mongoose')

var user_login = new mongoose.Schema({

    name: {
        type: String,
    },
    email: {
        type: String,
    },
    password: {
        type: String,
    },
    
})

module.exports = mongoose.model('user_login', user_login);