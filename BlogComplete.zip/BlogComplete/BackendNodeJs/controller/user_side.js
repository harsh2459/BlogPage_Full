var login = require('../model/user_login');
var signup = require('../model/user_signup');
var jwt = require('jsonwebtoken')

exports.user_signup = async (req, res) => {
    var check_name = await signup.find({ name: req.body.name })
    var check_email = await signup.find({ email: req.body.email })
    if (check_email.length == 0) {
        if (check_name.length == 0) {
            var data = signup.create(req.body)
            res.status(200).json({
                message: "user created successfully",
                result: data
            })
        } else {
            res.status(400).json({
                message: "user already exist"
            })
        }
    } else {
        res.status(400).json({
            message: "check email"
        })
    }
};


exports.delete_user = async (req, res) => {
    // Check if user exists with the provided name, email, and password
    var user = await signup.findOne({
        name: req.body.name,
        email: req.body.email,
        password: req.body.password
    });

    // If user is found, proceed to delete
    if (user) {
        await signup.deleteOne({ name: user.name }); // Delete the user by ID
        res.status(200).json({
            message: "User  deleted successfully"
        });
    } else {
        res.status(400).json({
            message: "User  not found or credentials are incorrect"
        });
    }
};


// <--- user login ---> //

exports.user_login = async (req, res) => {
    exports.user_login = async (req, res) => {
        // Check if user exists with the provided email and password
        var user = await signup.findOne({
            email: req.body.email,
            password: req.body.password
        });
    
        // If user is found, proceed to login
        if (user) {
           
            const token = jwt.sign({ id: user._id, name: user.name }, 'your_secret_key',)

            res.status(200).json({
                message: "Login successful",
                token: token
            });
        } else {
            res.status(400).json({
                message: "Invalid credentials, please create an account"
            });
        }
    };
}
