var category = require('../model/category_model');
var blog = require('../model/blog')

exports.add_category = async (req, res) => {

    var data = await category.create(req.body);

    res.status(200).json({
        message: 'category created successfully',
        data: data
    });
}

exports.show_category = async (req, res) => {
    var data = await category.find().sort({ createdAt: -1 });
    res.status(200).json({
        message: 'category Find successfully',
        data: data
    })
}

exports.delete_category = async (req, res) => {
    var id = req.params.id;
    var data = await category.findByIdAndDelete(id);
    res.status(200).json({
        message: 'category deleted successfully',
    })
}


exports.update_category = async (req, res) => {
    var id = req.params.id;
    var data = await category.findByIdAndUpdate(id,req.body)
    res.status(200).json({
        message: 'category update successfully',
        data
    })
}

exports.short_by_category = async (req, res) => {
    const category = req.params.category;

    try {
        const categoryBlogs = await blog.find({ category: category });

        res.status(200).json({
            message: 'Blog posts retrieved successfully',
            data: categoryBlogs
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Error retrieving blog posts' });
    }
};