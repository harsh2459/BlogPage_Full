var blog = require('../model/blog')

exports.add_blog = async (req, res) => {

    const date = new Date();
    req.body.date = date
    const data = await blog.create(req.body);

    res.status(200).json({
        message: 'Blog post created successfully',
        data: data
    });

};

exports.get_blog_posts = async (req, res) => {

    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const blogPosts = await blog.find().skip(skip).limit(limit).sort({ date: -1 });
    const totalPosts = await blog.countDocuments();

    return res.status(200).json({
        message: 'Blog posts retrieved successfully',
        data: blogPosts,
        total: totalPosts,
        page: page,
        totalPages: Math.ceil(totalPosts / limit)
    });

};

exports.single_blog = async (req, res) => {
    const id = req.params.id;
    const data = await blog.findById(id)
    console.log(data);

    if (data.length === 0) {
        res.status(400).json({
            message: "Blog Post Not Found"
        })
    } else {
        res.status(200).json({
            message: 'Blog post retrieved successfully',
            data: data
        });
    }
}


exports.update_blog = async (req, res) => {
    const id = req.params.id;
    try {
        const blogPost = await blog.findByIdAndUpdate(id, req.body, {
            new: true
        });
        if (!blogPost) {
            return res.status(404).json({ message: 'Blog post not found' });
        }
        return res.status(200).json({
            message: 'Blog post updated successfully',
            post: blogPost
        });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Error updating blog post' });
    }
}

exports.delete_blog = async (req, res) => {
    const id = req.params.id;
    try {
        await blog.findByIdAndDelete(id);
        return res.status(200).json({ message: 'Blog post deleted successfully' });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: 'Error deleting blog post' });
    }
}


exports.commment_add = async (req, res) => {
    const id = req.params.id;
    const comment = req.body.comment;
    try {
        const blogPost = await blog.findById(id);
        if (!blogPost) {
            return res.status(404).json({ message: 'Blog post not found' });
        }
        const newComment = new commentModel({
            comment: comment,
            blogPost: blogPost._id
        });
        await newComment.save
        blogPost.comments.push(newComment._id);
        await blogPost.save
        return res.status(200).json({
            message: 'Comment added successfully',
            comment: newComment
        })
    }
    catch {
        console.error(error);
        return res.status(500).json({ message: 'Error adding comment' });

    }
}